from django.apps import AppConfig


class PythonbeltConfig(AppConfig):
    name = 'pythonbelt'
